﻿using System;
using System.Threading.Tasks;
using Azure.Storage.Queues;
using Azure.Storage.Queues.Models;

namespace ST10092086_POE_Part2
{
    class Program
    {
        // adapted from stackoverflow
        // https://stackoverflow.com/questions/11743160/how-do-i-encode-and-decode-a-base64-string
        // By Kevin Driedger
        // https://stackoverflow.com/users/9587/kevin-driedger
        // Accessed 21 October 2022
        public static string Base64Encode(string plainText)
        {
            var plainTextBytes = System.Text.Encoding.UTF8.GetBytes(plainText);
            return System.Convert.ToBase64String(plainTextBytes);
        }
        static async Task Main(string[] args)
        {
            //get a coinnection string

            //adapted from Microsoft
            //https://learn.microsoft.com/en-us/azure/storage/common/storage-configure-connection-string
            //Accessed 21 October 2022
            string connectionString
                = "DefaultEndpointsProtocol=https;AccountName=awehproductionslkm;AccountKey=RgOpiGAzux9RU92Xut66BWFiLeJyaVO+UvjLw06zUCCyEijLCka+mxhqNZMm91ZvnOA/IYrgKWu9+AStUptsbg==;EndpointSuffix=core.windows.net";

            //create a que manually

            //adapted from GeeksForGeeks
            //https://www.geeksforgeeks.org/how-to-create-a-queue-in-c-sharp/
            //Accessed 21 October 2022
            string queName = "awehprod-que";
            QueueClient queueClient = new QueueClient(connectionString, queName);


            await queueClient.CreateAsync();

            //creating an array to store messages
            String[] messages = new string[]
            { "87022546594447:Tulip Waterfall:2020/12/13:OT234", "990508634178985:White JHB:2021/03/17:TK0921",
                "0506215084893:Cancion Waterfall:2020/10/17:CXB07172", "9010305063081:Tulip JHB:2022/01/23:SDE20002",
                "03110964321908:Dwala Tembisa:2020/07/10:TKM9007",
               "VMJ20981:2021/02/12:Grande Greennstone:032210210949",
                "DAN109:2021/01/19:Tulip Waterfall:01103483838292", "SOM217:2021/01/09:Cancion Waterfall:021208374621",
                "BUT892:2021/09/12:Tulip Tembisa:Id", "BOU5327:2020/02/02:Tulip Florida:847882293721"  };



            //insert messages into que
            await queueClient.SendMessageAsync(Base64Encode(messages[0]));
            await queueClient.SendMessageAsync(Base64Encode(messages[1]));
            await queueClient.SendMessageAsync(Base64Encode(messages[2]));
            await queueClient.SendMessageAsync(Base64Encode(messages[3]));
            await queueClient.SendMessageAsync(Base64Encode(messages[4]));
            await queueClient.SendMessageAsync(Base64Encode(messages[5]));
            await queueClient.SendMessageAsync(Base64Encode(messages[6]));
            await queueClient.SendMessageAsync(Base64Encode(messages[7]));
            await queueClient.SendMessageAsync(Base64Encode(messages[8]));
            await queueClient.SendMessageAsync(Base64Encode(messages[9]));


        }
    }
}
