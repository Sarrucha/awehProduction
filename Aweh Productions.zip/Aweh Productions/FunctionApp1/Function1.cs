using System;
using System.Threading.Tasks;
using Microsoft.Azure.Cosmos.Table;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Host;
using Microsoft.Extensions.Logging;
using Microsoft.WindowsAzure.Storage.Table;
using CloudTable = Microsoft.Azure.Cosmos.Table.CloudTable;
using CloudTableClient = Microsoft.Azure.Cosmos.Table.CloudTableClient;
using TableEntity = Microsoft.Azure.Cosmos.Table.TableEntity;
using TableOperation = Microsoft.Azure.Cosmos.Table.TableOperation;
using TableResult = Microsoft.Azure.Cosmos.Table.TableResult;

namespace FunctionApp1
{
    public class Function1
    {
        [FunctionName("AweProdQueTrigger")]
        public static async Task Run([QueueTrigger("awehprod-que", Connection = "awehCon")]string myQueueItem, ILogger log)
        {
            log.LogInformation($"C# Queue trigger function processed: {myQueueItem}");

            int count = 0;

            try
            {
                var storageConnectionString = "DefaultEndpointsProtocol=https;AccountName=awehproductionslkm;AccountKey=RgOpiGAzux9RU92Xut66BWFiLeJyaVO+UvjLw06zUCCyEijLCka+mxhqNZMm91ZvnOA/IYrgKWu9+AStUptsbg==;EndpointSuffix=core.windows.net";
                var tableName = "Vaccinations";

                //adapted from geekculture
                //https://medium.com/geekculture/using-the-new-c-azure-data-tables-sdk-with-azure-cosmos-db-786085ac8190
                //Adapted from Will Velida
                //https://medium.com/@willvelida?source=---three_column_layout_sidebar
                //Accessed 25 Novemeber 2022

                CloudStorageAccount storageAccount = CloudStorageAccount.Parse(storageConnectionString);

                CloudTableClient tableClient = storageAccount.CreateCloudTableClient(new TableClientConfiguration());

                CloudTable table = tableClient.GetTableReference(tableName);

                //break up vaccination details to use the ID and vaccination barcode or serial number

                //adapted from GeeksForGeeks
                //https://www.geeksforgeeks.org/string-split-method-in-c-sharp-with-examples/
                //accessed on 24 November 2022

                String[] spearator = { ":" };
                count = 4;

                // using the method
                String[] strlist = myQueueItem.Split(spearator, count,
                       StringSplitOptions.RemoveEmptyEntries);



                VacDetail vacDetail = new VacDetail { PartitionKey = "1", RowKey = strlist[0], vaccInformation = myQueueItem };

                MergeUser(table, vacDetail).Wait();
            }
            catch (ArgumentOutOfRangeException)
            {
                log.LogInformation($"Unable to add: {myQueueItem}");
            }
            catch (ArgumentException)
            {
                log.LogInformation($"Unable to add: {myQueueItem}");

            }
            catch (FormatException)
            {
                log.LogInformation($"Unable to add: {myQueueItem}");

            }
           




        }
        //adapted from YouTube.com
        //https://www.youtube.com/watch?v=HSL1poL1VR0&t=25s
        //Adapted from Adam Marczak
        //https://www.youtube.com/@Azure4Everyone
        //Accesed 23 Novemebr 2022

        public static async Task MergeUser(CloudTable table, VacDetail vac)
        {
            TableOperation insertMergeOperation = TableOperation.InsertOrMerge(vac);

            //Excecute the operation
            TableResult result = await table.ExecuteAsync(insertMergeOperation);
            VacDetail insertedDetail = result.Result as VacDetail;

            
        
        
        }

    }

    public class VacDetail : TableEntity
    {

        public String vaccInformation { get; set; }
    }
}
